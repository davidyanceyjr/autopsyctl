# repo-state

Purpose
-------
Inspect the repository and determine the current engineering state.

Procedure
---------
1. Inspect `git status --short`, current branch, `gh issue list`, `gh pr list`, `spec/`, `docs/design/`, `src/`, `test/`, `README.md`, and `SESSION.md`.
2. Identify the active issue if branch naming or notes make it obvious.
3. Check whether the issue has a spec, design doc, implementation changes, tests, and a PR.
4. Classify the stage as one of: issue, spec, design, implementation, test, debug, review, merge, docs.
5. Identify missing artifacts and blockers.
6. Report one recommended next step.

Output
------
Stage, findings, risks, and one recommended next step.
