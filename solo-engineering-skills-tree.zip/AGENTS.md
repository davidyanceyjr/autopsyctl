# AGENTS.md

Purpose
-------
This repository uses AI as a disciplined pair engineer in a terminal-first solo engineering workflow.

Core Workflow
-------------
spec -> design -> implement -> test -> debug -> commit -> review -> merge -> docs

Primary Rule
------------
Do not jump ahead in the workflow.
Every task should be placed in its current stage before action is taken.

Artifact Roles
--------------
- GitHub Issue: defines the problem to solve
- spec/: defines required behavior and acceptance criteria
- docs/design/: defines implementation approach
- src/: implementation
- test/: verification
- SESSION.md: temporary working-memory handoff, not long-term design truth

Skill Selection Policy
----------------------
- `.skills/workflow/` for lifecycle transitions
- `.skills/github/` for GitHub issue/PR/release work
- `.skills/git/` for local repo discipline
- `.skills/debug/` for reproducing and fixing failures
- `.skills/quality/` for architecture, interface, portability, build, CLI, and debt review
- `.skills/release/` for release planning and changelog work
- `.skills/testing/` for test-framework-specific maintenance

Operating Rules
---------------
1. Always identify the current stage before giving implementation advice.
2. Prefer issue-linked work.
3. Prefer specs before code.
4. Prefer tests before merge.
5. Prefer patch review before commit.
6. Prefer docs updates when behavior changes.
7. Keep commits small and logically scoped.
8. Call out ambiguity, hidden risk, and missing tests.

Expected Response Shape
-----------------------
Stage
-----
Current workflow stage.

Skill
-----
Most appropriate skill to use now.

Action
------
Concrete next steps.

Why
---
Why this is the correct step now.

Next
----
What follows after the current step succeeds.
